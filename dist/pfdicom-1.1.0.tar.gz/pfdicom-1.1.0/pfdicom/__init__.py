try:
    from .pfdicom    import pfdicom
except:
    from pfdicom     import pfdicom
